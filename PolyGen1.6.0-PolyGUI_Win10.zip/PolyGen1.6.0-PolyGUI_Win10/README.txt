******************************************************************************
*                                                                            *
*                           PolyGen for Windows 10                           *
*                                                                            *
******************************************************************************
This package contains all the required binaries for using PolyGen and PolyGUI
under Windows 10. Tested under Windows 10 x64, v1709 ("Fall Creators Update"):

 * polygen.exe  -- PolyGen v1.0.6 built 20051011 (GPLv2+)
 * cygwin1.dll  -- Cygwin DLL v2.9.0-3 (GPLv3+)
 * PolyGUI.exe  -- PolyGUI v1.3.1 (Freeware)

Both "polygen.exe" and "PolyGUI.exe" were executed without need of resorting to
Compatibility Mode; "polygen.exe" was tested both in CMD and Bash for Windows,
and worked fine without warnings or errors.

You're advised to keep all three files in the same folder: "PolyGUI.exe" needs
"polygen.exe" in order to work, and "polygen.exe" requires "cygwin1.dll".

SOURCE AND LICENSE FILES 
========================

In compliance to the terms of the GNU General Public License (GPL), the source
code of PolyGen and Cygwin DLL are also included:

 * polygen-1.0.6-20040628-src.zip
 * cygwin-2.9.0-3-src.tar.xz

Along with the files of their full licenses text:

 * GPLv2.0.txt
 * GPLv3.0.txt

==============================================================================
                                About PolyGen                                 
==============================================================================

PolyGen was downloaded from:

   http://www.polygen.org/it/download

PolyGen was created by Alvise Spano', Copyright (C) 2002-03 Alvise Spano', and
released under the GNU General Public License version 2 (or any later version).

For the full text of the GNU GPL v2, see:

 * GPLv2.0.txt

For help on how to use PolyGen from the command line, open a CMD instance in
this folder and type:

  polygen

------------------------------------------------------------------------------
                               PolyGen License                                
------------------------------------------------------------------------------

PolyGen
Copyright (C) 2002-03 Alvise Spano'

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

==============================================================================
                                About PolyGUI                                 
==============================================================================

PolyGUI is a graphical user interface for editing and testing PolyGen grammar
source files. The generated text output can be viewed both in plaintext format
and in HTML preview. It was downloaded from:

   http://www.polygen.org/it/download

PolyGUI was created by ^anakin^, and published on www.polygen.org for free
download. There are no license terms for PolyGUI, it's a freeware tool which has
been freely shared for over two decades amongst the PolyGen community, with its 
author's approval.

==============================================================================
                               About Cygwin DLL                               
==============================================================================

The Cygwin DLL binary ("cygwin1.dll") was taken from the "cygwin-2.9.0-3.tar.xz"
package, downloaded from:

   http://mirrors.kernel.org/sourceware/cygwin/x86/release/cygwin/

Cygwin DLL is released under the GNU General Public License version 3 (or any
later version).

For the full text of the GNU GPL v3, see:

 * GPLv3.0.txt

For more information on Cygwin DLL, visit the Cygwin project:

   https://www.cygwin.com/

------------------------------------------------------------------------------
                              Cygwin DLL License                              
------------------------------------------------------------------------------

THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESSED OR
IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

Unless stated otherwise, the sources under the cygwin subdirectory,
as well as the sources under the cygserver subdirectory linked into
the Cygwin DLL, are licensed under the Lesser Gnu Public License,
version 3 or (at your option) any later version (LGPLv3+).  See the
COPYING.LIB file for the exact wording of that license.

Unless stated otherwise, the sources under the cygserver subdir not
linked into the Cygwin DLL, as well as the sources under the lsaauth
and the utils subdirectories are licensed under the Gnu Public License,
version 3 or (at your option) any later version (GPLv3+).  See the
COPYING file for the exact wording of that license. 

Parts of the sources in any subdirectory are licensed using a BSD-like
license.  The affected source files contain explicit copyright notices
to that effect.

Linking Exception:

  As a special exception, the copyright holders of the Cygwin library
  grant you additional permission to link libcygwin.a, crt0.o, and
  gcrt0.o with independent modules to produce an executable, and to
  convey the resulting executable under terms of your choice, without
  any need to comply with the conditions of LGPLv3 section 4. An
  independent module is a module which is not itself based on the
  Cygwin library.
